from typing import Tuple


def controlla_segno(numero_1:float, numero_2:float)->Tuple[list, float, float]:
    '''
    Parameters
    ----------
    numero_1 : float
        
    numero_2 : float
        

    Returns
    -------
    Tuple(list, float, float)
        list: formata da due elementi
                                    il primo indica se l'operazione sarà addizione o sottrazione
                                    il secondo il segno del risultato finale
        float: valore assoluto numero_1
        float: valore assoluto numero_2

    '''
    if (numero_1 >= 0) and (numero_2 >= 0):
        segno = ['più', 'più']
    elif (numero_1 >= 0): # numero_2 sicuramente negativo
        numero_2 = abs(numero_2)
        if numero_2 <= numero_1: #la sottrazione avrà risultato positivo
            segno = ['meno', 'più']
        else: #la sottrazione avrà risultato negativo(sottraggo per un numero >)
            segno = ['meno', 'meno']
            #scambio i valori di numero_1 e numero_2
            n = numero_1 
            numero_1 = numero_2
            numero_2 = n
    elif (numero_2 >= 0): #numero_1 sicuramente negativo
        numero_1 = abs(numero_1)
        if numero_2 <= numero_1: #la sottrazione avrà risultato negativo(sottraggo per un numero >)
            segno = ['meno', 'meno']
        else: #la sottrazione avrà risultato positivo
            segno = ['meno', 'più']
             #scambio i valori di numero_1 e numero_2
            n = numero_1 
            numero_1 = numero_2
            numero_2 = n
    else:
        numero_1 = abs(numero_1)
        numero_2 = abs(numero_2)
        segno = ['più', 'meno'] #la somma di 2 numeri negativi è un numero negativo
    return (segno, numero_1, numero_2)



def check_lenght(numero_1:str, numero_2:str)->Tuple[str, str]:
    '''
    eguaglia la lunghezza dei due numeri aggiungendo zeri
    indispensabile per poter sommare/sottrarre ogni singolo elemento col ciclo for
    Parameters
    ----------
    numero_1 : str
        
    numero_2 : str
        

    Returns
    -------
    Tuple(str, str)
        DESCRIPTION.

    '''
    #calcolo la lunghezza delle parti intere dei due numeri
    lungh_1 = len(str(int(float(numero_1))))
    lungh_2 = len(str(int(float(numero_2))))
    
    # eguaglio la lunghezza delle 2 parti intere
    while lungh_1 < lungh_2 :
        numero_1 = '0' + numero_1
        lungh_1 += 1
    while lungh_2 < lungh_1:
        numero_2 = '0' + numero_2
        lungh_2 += 1
    
    #eguaglio la lunghezza dei due numeri
    while len(numero_1) > len(numero_2):
        numero_2 += '0'
    while len(numero_2) > len(numero_1):
        numero_1 += '0'
    
    return numero_1, numero_2



def addizione(numero_1:str, numero_2:str)->float:
    '''
    esegue l'addizione in colonna fra i due numeri
    nel caso in cui un elemento del risultato sia > 10 gli toglie dieci e aggiunge 1 al successivo

    Parameters
    ----------
    numero_1 : str
        
    numero_2 : str
        

    Returns
    -------
    float
        risultato dell'addizione

    '''
    risultato = [str(int(numero_1[i]) + int(numero_2[i])) if numero_1[i] != '.' else '.' for i in range(len(numero_2))]
    for i in range(len(risultato) - 1, -1, -1):
        try:
            if (int(risultato[i]) > 9) and (i > 0) :
                risultato[i] = str(int(risultato[i]) - 10)
                if risultato[i-1] == '.':
                    risultato[i-2] = str(int(risultato[i-2]) + 1)
                else:
                    risultato[i-1] = str(int(risultato[i-1])+ 1)
        except ValueError: # impossibile fare int('.')
            pass
    risultato = ''.join(risultato)
    return float(risultato)



def sottrazione(numero_1:str, numero_2:str)->float:
    '''
    esegue la sottrazione in colonna tra due numeri
    nel caso in cui un elemento del risultato sia < 0 gli aggiunge 10  e toglie 1 al successivo

    Parameters
    ----------
    numero_1 : str
        
    numero_2 : str
        

    Returns
    -------
    float
        risultato della sottrazione

    '''
    risultato = [str(int(numero_1[i]) - int(numero_2[i])) if numero_1[i] != '.' else '.' for i in range(len(numero_2))]
    for i in range(len(risultato) - 1, -1, -1):
        try:
            if (int(risultato[i]) < 0) and (i > 0) :
                risultato[i] = str(int(risultato[i]) + 10)
                if risultato [i-1] == '.':
                    risultato[i-2] = str(int(risultato[i-2])-1)
                else:
                    risultato[i-1] = str(int(risultato[i-1])- 1)
        except ValueError: # impossibile fare int('.')
            pass
    risultato = ''.join(risultato)
    return float(risultato)



def somma_algebrica(numero_1:float, numero_2:float)->float:
    #controllo il segno dei numeri e ne ritorno il valore assoluto
    tupla = controlla_segno(numero_1, numero_2)
    segno = tupla[0]
    numero_1 = str(tupla[1])
    numero_2 = str(tupla[2]) 
    
    #eguaglio la lunghezza dei due numeri
    tupla = check_lenght(numero_1, numero_2)   
    numero_1 = tupla[0]
    numero_2 = tupla[1]
    
    #in base al segno eseguo o sottrazione o addizione
    if segno[0] == 'più':
        risultato = addizione(numero_1, numero_2)    
    else:
        risultato = sottrazione(numero_1, numero_2)
    
    #ritorno il risultato col segno corretto
    if segno[1] == 'meno':
        return - (risultato)
    return (risultato) #inutile scrivere else perchè arriva qui solo se non si è verificata la condizione precedente



     
        
    
     
       
        